package androidx.lifecycle;

/* renamed from: androidx.lifecycle.R */
public final class C0282R {
    private C0282R() {
    }
}
