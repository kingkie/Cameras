package androidx.lifecycle.viewmodel;

/* renamed from: androidx.lifecycle.viewmodel.R */
public final class C0288R {
    private C0288R() {
    }
}
