package androidx.lifecycle.livedata.core;

/* renamed from: androidx.lifecycle.livedata.core.R */
public final class C0287R {
    private C0287R() {
    }
}
