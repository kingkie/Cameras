package androidx.lifecycle.livedata;

/* renamed from: androidx.lifecycle.livedata.R */
public final class C0286R {
    private C0286R() {
    }
}
