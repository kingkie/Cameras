package androidx.multidex;

/* renamed from: androidx.multidex.R */
public final class C0335R {
    private C0335R() {
    }
}
