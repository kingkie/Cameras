package androidx.viewpager;

import com.naxclow.v720.C1921R;

/* renamed from: androidx.viewpager.R */
public final class C0429R {

    /* renamed from: androidx.viewpager.R$attr */
    public static final class attr {
        public static final int alpha = 2130837553;
        public static final int font = 2130837643;
        public static final int fontProviderAuthority = 2130837645;
        public static final int fontProviderCerts = 2130837646;
        public static final int fontProviderFetchStrategy = 2130837647;
        public static final int fontProviderFetchTimeout = 2130837648;
        public static final int fontProviderPackage = 2130837649;
        public static final int fontProviderQuery = 2130837650;
        public static final int fontStyle = 2130837651;
        public static final int fontVariationSettings = 2130837652;
        public static final int fontWeight = 2130837653;
        public static final int ttcIndex = 2130837850;

        private attr() {
        }
    }

    /* renamed from: androidx.viewpager.R$color */
    public static final class color {
        public static final int notification_action_color_filter = 2130968659;
        public static final int notification_icon_bg_color = 2130968660;
        public static final int ripple_material_light = 2130968671;
        public static final int secondary_text_default_material_light = 2130968673;

        private color() {
        }
    }

    /* renamed from: androidx.viewpager.R$dimen */
    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131034187;
        public static final int compat_button_inset_vertical_material = 2131034188;
        public static final int compat_button_padding_horizontal_material = 2131034189;
        public static final int compat_button_padding_vertical_material = 2131034190;
        public static final int compat_control_corner_material = 2131034191;
        public static final int compat_notification_large_icon_max_height = 2131034192;
        public static final int compat_notification_large_icon_max_width = 2131034193;
        public static final int notification_action_icon_size = 2131034220;
        public static final int notification_action_text_size = 2131034221;
        public static final int notification_big_circle_margin = 2131034222;
        public static final int notification_content_margin_start = 2131034223;
        public static final int notification_large_icon_height = 2131034224;
        public static final int notification_large_icon_width = 2131034225;
        public static final int notification_main_column_padding_top = 2131034226;
        public static final int notification_media_narrow_margin = 2131034227;
        public static final int notification_right_icon_size = 2131034228;
        public static final int notification_right_side_padding_top = 2131034229;
        public static final int notification_small_icon_background_padding = 2131034230;
        public static final int notification_small_icon_size_as_large = 2131034231;
        public static final int notification_subtext_size = 2131034232;
        public static final int notification_top_pad = 2131034233;
        public static final int notification_top_pad_large_text = 2131034234;

        private dimen() {
        }
    }

    /* renamed from: androidx.viewpager.R$drawable */
    public static final class C0430drawable {
        public static final int notification_action_background = 2131099833;
        public static final int notification_bg = 2131099834;
        public static final int notification_bg_low = 2131099835;
        public static final int notification_bg_low_normal = 2131099836;
        public static final int notification_bg_low_pressed = 2131099837;
        public static final int notification_bg_normal = 2131099838;
        public static final int notification_bg_normal_pressed = 2131099839;
        public static final int notification_icon_background = 2131099840;
        public static final int notification_template_icon_bg = 2131099841;
        public static final int notification_template_icon_low_bg = 2131099842;
        public static final int notification_tile_bg = 2131099843;
        public static final int notify_panel_notification_icon_bg = 2131099844;

        private C0430drawable() {
        }
    }

    /* renamed from: androidx.viewpager.R$id */
    public static final class C0431id {
        public static final int action_container = 2131165214;
        public static final int action_divider = 2131165216;
        public static final int action_image = 2131165217;
        public static final int action_text = 2131165223;
        public static final int actions = 2131165224;
        public static final int async = 2131165243;
        public static final int blocking = 2131165249;
        public static final int chronometer = 2131165277;
        public static final int forever = 2131165357;
        public static final int icon = 2131165424;
        public static final int icon_group = 2131165425;
        public static final int info = 2131165434;
        public static final int italic = 2131165435;
        public static final int line1 = 2131165452;
        public static final int line3 = 2131165453;
        public static final int normal = 2131165475;
        public static final int notification_background = 2131165476;
        public static final int notification_main_column = 2131165477;
        public static final int notification_main_column_container = 2131165478;
        public static final int right_icon = 2131165516;
        public static final int right_side = 2131165517;
        public static final int tag_transition_group = 2131165576;
        public static final int tag_unhandled_key_event_manager = 2131165577;
        public static final int tag_unhandled_key_listeners = 2131165578;
        public static final int text = 2131165579;
        public static final int text2 = 2131165580;
        public static final int time = 2131165590;
        public static final int title = 2131165591;

        private C0431id() {
        }
    }

    /* renamed from: androidx.viewpager.R$integer */
    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 2131230725;

        private integer() {
        }
    }

    /* renamed from: androidx.viewpager.R$layout */
    public static final class C0432layout {
        public static final int notification_action = 2131296334;
        public static final int notification_action_tombstone = 2131296335;
        public static final int notification_template_custom_big = 2131296342;
        public static final int notification_template_icon_group = 2131296343;
        public static final int notification_template_part_chronometer = 2131296347;
        public static final int notification_template_part_time = 2131296348;

        private C0432layout() {
        }
    }

    /* renamed from: androidx.viewpager.R$string */
    public static final class C0433string {
        public static final int status_bar_notification_info_overflow = 2131558750;

        private C0433string() {
        }
    }

    /* renamed from: androidx.viewpager.R$style */
    public static final class C0434style {
        public static final int TextAppearance_Compat_Notification = 2131624236;
        public static final int TextAppearance_Compat_Notification_Info = 2131624237;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131624239;
        public static final int TextAppearance_Compat_Notification_Time = 2131624242;
        public static final int TextAppearance_Compat_Notification_Title = 2131624244;
        public static final int Widget_Compat_NotificationActionContainer = 2131624354;
        public static final int Widget_Compat_NotificationActionText = 2131624355;

        private C0434style() {
        }
    }

    /* renamed from: androidx.viewpager.R$styleable */
    public static final class styleable {
        public static final int[] ColorStateListItem = {16843173, 16843551, C1921R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] FontFamily = {C1921R.attr.fontProviderAuthority, C1921R.attr.fontProviderCerts, C1921R.attr.fontProviderFetchStrategy, C1921R.attr.fontProviderFetchTimeout, C1921R.attr.fontProviderPackage, C1921R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, C1921R.attr.font, C1921R.attr.fontStyle, C1921R.attr.fontVariationSettings, C1921R.attr.fontWeight, C1921R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;

        private styleable() {
        }
    }

    private C0429R() {
    }
}
