package androidx.localbroadcastmanager;

/* renamed from: androidx.localbroadcastmanager.R */
public final class C0300R {
    private C0300R() {
    }
}
